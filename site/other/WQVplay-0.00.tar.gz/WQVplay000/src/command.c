#include "config.h"
#include <stdio.h>
#include <sys/types.h>
#include "common.h"
#ifdef X68
#include "tty_x68.h"
#else
#ifdef WIN32
#include "tty_w32.h"
#else
#ifdef OS2
#include "tty_os2.h"
#else
#ifdef DOS
#include "tty_dos.h"
#else
#include "tty.h"
#include <termios.h>
#endif /* DOS */
#endif /* OS2 */
#endif /* WIN32 */
#endif /* X68K */
#if HAVE_UNISTD_H
#include <unistd.h>
#endif


#include <stdlib.h>

#if 0
# define dprintf(x)	fprintf x
#else
# define dprintf(x)
#endif

static int	WQVfd = -1;

void
WQVsetfd(fd)
     int	fd;
{
  WQVfd = fd;
}

int
WQVgetfd()
{
  return WQVfd;
}

/*------------------------------------------------------------*/

unsigned char WQVmake_connection  P__((void))
{
  /* if connection was not established return 0 */
  /* return connection id */
  int ret;
  unsigned char buf[16];
  unsigned short s;
  unsigned char id;
  buf[0] = 0xff;
  buf[1] = 0xb3;
  buf[2] = 0x01;
  buf[3] = 0xb2;
  ret = writetty0(WQVfd, buf, 4);
  ret = readtty0(WQVfd, buf, 8);
  buf[0] = 0xff;
  buf[1] = 0x93;
  /* 2 3 4 5 is same */

  s = buf[6] * 256 + buf[7];
  srand((unsigned int) s);
  id = 1+ (int) (255.0 * rand()/(RAND_MAX+1.0));
  s = s + id - 0x10;
  buf[6] = id;
  buf[7] = (s >> 8 ) & 0xff;
  buf[8] = s & 0xff;
  
  ret = writetty0(WQVfd, buf, 9);

  ret = readtty(WQVfd, buf, 3);
  ret = readtty(WQVfd, buf, 3);
  ret = readtty(WQVfd, buf, 3);

  /* check ret */
  
  return(id);
  
}

int next_prev_picture(int isnext)
{
  int ret;
  unsigned char buf[16];
  unsigned char id;

  id = WQVmake_connection();
  dprintf((stderr,"connection id %02x\n", id));

  buf[0] = id;
  buf[1] = 0x11;
  buf[2] = 0x00;
  ret = writetty(WQVfd, buf, 3);
  ret = readtty(WQVfd, buf, 3);


  buf[0] = id;
  buf[1] = 0x10;
  if(isnext != 0)
    buf[2] = 0x02;   /* page next */
  else
    buf[2] = 0x03;  /* page prev */
  buf[3] = 0x00;
  ret = writetty(WQVfd, buf, 4);
  ret = readtty(WQVfd, buf, 3);

  /* */
  buf[0] = id;
  buf[1] = 0x11;
  buf[2] = 0x00;
  ret = writetty(WQVfd, buf, 3);
  ret = readtty(WQVfd, buf, 4);
  
  /* */
  buf[0] = id;
  buf[1] = 0x32;
  buf[2] = 0x08;
  buf[3] = 0x00;
  buf[4] = 0x00;
  ret = writetty(WQVfd, buf, 5);
  ret = readtty(WQVfd, buf, 3);

  /* */
  buf[0] = id;
  buf[1] = 0x53;
  /*
    buf[2] = 0x00;  */  /* 01 ? */
  ret = writetty(WQVfd, buf, 3);
  ret = readtty(WQVfd, buf, 3);

  return 1;
}

int WQVnext_picture()
{
  return next_prev_picture(1);
}

int WQVprev_picture()
{
  return next_prev_picture(0);
}

int WQVget_a_picture(unsigned char *databuf, int data_size, int verbose)
{
  int ret;
  unsigned char get_magic1[8] = { 0x11, 0x31, 0x51, 0x71, 0x91, 0xb1, 0xd1, 0xf1 };
  unsigned char get_resp[8] ={ 0x40, 0x42, 0x44, 0x46, 0x48, 0x4a, 0x4c, 0x4e };

  unsigned char get_magic2[8];
  unsigned char buf[200];
  unsigned char id;

  unsigned char *p;

  int i, j;

  int total;

  total = 0;


  id = WQVmake_connection();
  dprintf((stderr,"connection id %02x\n", id));

  p = databuf;

  buf[0] = id;
  buf[1] = 0x11;
  buf[2] = 0x00;
  ret = writetty(WQVfd, buf, 3);
  ret = readtty(WQVfd, buf, 3);

  buf[0] = id;
  buf[1] = 0x10;
  buf[2] = 0x00;   /* get page  */
  buf[3] = 0x00;
  ret = writetty(WQVfd, buf, 4);
  ret = readtty(WQVfd, buf, 3);

  /* */
  buf[0] = id;
  buf[1] = 0x11;
  buf[2] = 0x00;
  ret = writetty(WQVfd, buf, 3);
  ret = readtty(WQVfd, buf, 8);
  
  /* */
  buf[0] = id;
  buf[1] = 0x32;
  buf[2] = 0x06;
  buf[3] = 0x00;
  ret = writetty(WQVfd, buf, 4);
  ret = readtty(WQVfd, buf, 3);

  
  /* 57 times 128 bytes */
  j = ((id >> 5) & 0x7) + ((id >> 4) & 0x1);
  /*  j = (id >> 5) & 0x7; */
  memset(get_magic2, 0x00, 8);
  for(i = 0 ; i < j ; i ++){
    get_magic2[7 - i] = 0x01;
  }


  j = 1; /* start  0x31 */
  for(i = 0; i < 57 ; i++){
    buf[0] = id;
    buf[1] = get_magic1[j];
    buf[2] = get_magic2[j];
    buf[3] = 0xff & (buf[0] + buf[1]);
    ret = writetty0(WQVfd, buf, 4);
    ret = readtty(WQVfd, buf, 128 + 2 + 2); /* 133 */
    /* check sum are last 2 bytes maybe */

    if(ret >0 ){
      memcpy(p, buf + 3 , ret - 5);
      p = p + (ret - 5);
      total = total + ret - 5;
    }
    
    if(verbose != 0){
      fprintf(stderr, "%4d/", total);
      fprintf(stderr, "%4d", BINFILESIZE);
      fprintf(stderr, "\b\b\b\b\b\b\b\b\b");
    }
    dprintf((stderr, "read(%d) %d\n", i, ret));
    j++;
    if( j > 7 ) j = 0;
  }
  if(verbose != 0)
    fprintf(stderr, "\n");
  
  /* */
  buf[0] = id;
  buf[1] = 0x54;
  buf[2] = 0x06;
  buf[3] = 0x00;
  ret = writetty(WQVfd, buf, 4);
  ret = readtty(WQVfd, buf, 3);

  /* */
  buf[0] = id;
  buf[1] = 0x53;
  buf[2] = 0x00;
  ret = writetty(WQVfd, buf, 3);
  ret = readtty(WQVfd, buf, 3);

  return 1;

}
