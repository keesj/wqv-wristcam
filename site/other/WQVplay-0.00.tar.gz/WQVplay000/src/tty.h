int	changespeed P__((int, int));
int	opentty P__((char *));
int	readtty P__((int, u_char *, int));
void	flushtty P__((int));
int    writetty P__((int, u_char *, int));
#define	closetty(fd)		close(fd)

int	readtty0 P__((int, u_char *, int));
int	_readtty P__((int, u_char *, int));
int    writetty0 P__((int, u_char *, int));
