#include "config.h"
#include <stdio.h>
#include <string.h>
#include <errno.h>
extern int errno;
#ifdef BINARYFILEMODE
#include <fcntl.h>  /* for setmode() */
#endif
#include <stdlib.h>
#include <time.h>
#if HAVE_UNISTD_H
# include <sys/types.h>
# include <unistd.h>
#endif
#if HAVE_SYS_PARAM_H
# include <sys/param.h>
#else
#define MAXPATHLEN 256
#endif
#include "common.h"
#include "command.h"
#ifdef X68
#include "tty_x68.h"
#else
#ifdef WIN32
#include "tty_w32.h"
#include "getopt.h"
#else
#ifdef OS2
#include "tty_os2.h"
#else
#ifdef DOS
#include "tty_dos.h"
#else
#include "tty.h"
#include <termios.h>
#endif /* DOS */
#endif /* OS2 */
#endif /* WIN32 */
#endif /* X68 */

#define MAX_PICTURE_NUM 100

#ifdef BINARYFILEMODE
#define WMODE "wb"
#define RMODE "rb"
#else
#define WMODE "w"
#define RMODE "r"
#endif


#define FILEFORMAT_PGM 0
#define FILEFORMAT_BIN 1

extern int	optind, opterr;
extern char	*optarg;


static	int	errflg = 0;

#ifndef DONTCAREUID
static	uid_t	uid, euid;
static	gid_t	gid, egid;
static	int	uidswapped = 0;
#endif

static int verbose = 0;
static int format = FILEFORMAT_PGM;

void usage()
{
  static	char	*usagestr[] =  {
    "wqvplay (Ver 0.00) Protocol test ver.\n",
    "(c)2000 Whole peoples on the earth.\n",
    "                    Programmed by Ken-ichi HAYASHI\n",
    "\t -n             : next picturen",
    "\t -p             : prev picture\n",
    "\t -F format      : picture format.[pgm bin]\n",
    "\t                  (use with -g).\n",
    "\t -g             : get current picture\n",
    "\t -v             : verbose mode(use with -a or -g)\n",
    "\t -D ttydevice   : set tty device.\n",
    "\t -h             : show this usage.\n",
    (char *)NULL,
  };
  char	**p;

  p = usagestr;
  while (*p)
    fprintf(stderr, *p++);
}

void Exit(code)
     int code;
{
  if (!(WQVgetfd() < 0)){
    closetty(WQVgetfd());
  }
  exit(code);
} 

#ifndef DONTCAREUID
void
daemonuid()
{
  if (uidswapped) {
#ifdef HAVE_SETREUID
    setreuid(uid, euid);
    setregid(gid, egid);
#else
    setuid(uid);
    seteuid(euid);
    setgid(gid);
    setegid(egid);
#endif
    uidswapped = 0;
  }
}

void
useruid()
{
  if (!uidswapped) {
#ifdef HAVE_SETREUID
    setregid(egid, gid);
    setreuid(euid, uid);
#else
    setgid(egid);
    setegid(gid);
    setuid(euid);
    seteuid(uid);
#endif
    uidswapped = 1;
  }
}
#endif

int 
get_a_picture()
{
  unsigned char buf[BINFILESIZE];
  int i;
  unsigned char u;

  WQVget_a_picture(buf, BINFILESIZE, verbose);

  if( format == FILEFORMAT_BIN){
    fwrite(buf, sizeof(unsigned char), BINFILESIZE, stdout);
  } else { /* PGM binary format */
    fprintf(stdout, "P5\n");
    fprintf(stdout, "# comment\n");
    fprintf(stdout, "120 120\n");
    fprintf(stdout, "15\n");
    for(i = 29 ; i < BINFILESIZE ; i++){
      u = buf[i];
      fputc( 0xf - (u & 0x0f), stdout);
      fputc( 0xf - ((u >> 4) & 0x0f), stdout);
    }
    
  }
  
    
}

int
main(argc, argv)
     int	argc;
     char	**argv;
{
  char	*devpath = NULL;
  int	c;
  int i;

#ifndef DONTCAREUID
  uid = getuid();
  euid = geteuid();
  gid = getgid();
  egid = getegid();
  useruid();
#endif

  devpath = getenv("WQVPLAYTTY");

  if(devpath == NULL){
    devpath = malloc(sizeof(char) * (strlen(RSPORT) +1));
    if(devpath == NULL) {
      fprintf(stderr, "can't malloc\n");
      exit(1);
    }
    strcpy(devpath, RSPORT);
  }

  for(i = 0 ; i < argc; i++){
    if(strcmp("-D", argv[i]) == 0){
      devpath = argv[i+1];
      break;
    }
    if(strcmp("-h", argv[i]) == 0){
      usage();
      exit(-1);
    }
  }

  if (devpath) {
#ifndef DONTCAREUID
    daemonuid();
#endif
    WQVsetfd(opentty(devpath));
#ifndef DONTCAREUID
    useruid();
#endif
    changespeed(WQVgetfd(), B115200);
  }
  if (WQVgetfd() < 0)
    Exit(1);

  while ((c = getopt(argc, argv, "D:vnpgF:")) != EOF) {
    switch(c) {
    case 'v':
      verbose = 1;
      break;
    case 'n':
      WQVnext_picture();      
      break;
    case 'p':
      WQVprev_picture();      
      break;
    case 'g':
      get_a_picture();
      break;
    case 'D':
      break; /* do nothing */
    case 'F':
      {
	switch(optarg[0]){
	case 'b':
	  format = FILEFORMAT_BIN;
	  break;
	default:
	  format = FILEFORMAT_PGM;
	  break;
	}
      }
      break;
    default:
      usage();
      Exit(-1);
    }
  }

  Exit (errflg ? 1 : 0);
}
