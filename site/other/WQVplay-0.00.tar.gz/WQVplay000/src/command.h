void	WQVsetfd P__((int));
int	WQVgetfd  P__((void));

unsigned char WQVmake_connection  P__((void));
int WQVnext_picture  P__((void));
int WQVprev_picture  P__((void));
int WQVget_a_picture  P__((u_char *, int, int));
